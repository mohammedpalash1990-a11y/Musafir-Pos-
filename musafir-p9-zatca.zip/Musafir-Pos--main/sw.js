var V='musafir-pos-v79';
var CORE=['./','./index.html','./order.html','./manifest.json','./menu-manifest.json','./logo-192.png','./logo-512.png','./favicon-32.png'];
var VID=[];
var FB='https://www.gstatic.com/firebasejs/10.12.2/';
var CDN=[FB+'firebase-app.js',FB+'firebase-auth.js',FB+'firebase-firestore.js',FB+'firebase-component.js',FB+'firebase-logger.js',FB+'firebase-util.js','https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700&family=Plus+Jakarta+Sans:wght@400;600;800&display=swap'];
self.addEventListener('install',function(e){e.waitUntil(caches.open(V).then(function(c){
 var core=CORE.map(function(u){return fetch(new Request(u,{cache:'reload'})).then(function(r){if(r&&r.ok)return c.put(u,r)}).catch(function(){})});
 var vid=VID.map(function(u){return fetch(new Request(u,{cache:'reload'})).then(function(r){if(r&&r.ok&&r.status===200)return c.put(u,r)}).catch(function(){})});
 var cdn=CDN.map(function(u){return c.add(u).catch(function(){})});
 return Promise.all(core.concat(vid,cdn))}).then(function(){return self.skipWaiting()}))});
self.addEventListener('activate',function(e){e.waitUntil(caches.keys().then(function(k){return Promise.all(k.filter(function(x){return x!==V}).map(function(x){return caches.delete(x)}))}).then(function(){return self.clients.claim()}))});

/* ভিডিও: পুরো ফাইল ক্যাশে রাখা হয় এবং Range অনুরোধে ক্যাশ থেকেই অফলাইনে চালানো হয় */
function vid(r){
 return caches.open(V).then(function(c){
  return c.match(r.url,{ignoreSearch:true}).then(function(hit){
   var get=hit?Promise.resolve(hit):fetch(r.url).then(function(n){if(n&&n.ok&&n.status===200){c.put(r.url,n.clone())}return n});
   return get.then(function(res){
    var rg=r.headers.get('range');
    if(!rg||!res||!res.ok||res.status!==200)return res;
    return res.clone().arrayBuffer().then(function(buf){
     var m=/bytes=(\d*)-(\d*)/.exec(rg),len=buf.byteLength,s=0,e=len-1;
     if(m){if(m[1]!==''){s=+m[1];if(m[2]!=='')e=Math.min(+m[2],len-1)}else if(m[2]!==''){s=Math.max(0,len-(+m[2]))}}
     if(s>e||s>=len)return new Response(null,{status:416,headers:{'Content-Range':'bytes */'+len}});
     return new Response(buf.slice(s,e+1),{status:206,statusText:'Partial Content',headers:{'Content-Type':res.headers.get('Content-Type')||'video/mp4','Content-Range':'bytes '+s+'-'+e+'/'+len,'Content-Length':String(e-s+1),'Accept-Ranges':'bytes'}})})})})
 }).catch(function(){return Response.error()})}

self.addEventListener('fetch',function(e){
 var r=e.request;if(r.method!=='GET')return;var u=new URL(r.url);if(/\/admin\.html$/.test(u.pathname))return;if(u.searchParams.has('_v'))return;var NAV=/\/order(\.htm)?(\.html)?(\/.*)?$|\/order\.htm/.test(u.pathname)?'./order.html':'./index.html';
 var ok=u.origin===location.origin||u.host==='www.gstatic.com'||u.host==='fonts.gstatic.com'||u.host==='fonts.googleapis.com';
 if(!ok)return;
 if(u.origin===location.origin&&/\.(mp4|webm)$/.test(u.pathname)){e.respondWith(vid(r));return}
 function swr(key,req){return caches.match(key,{ignoreSearch:true}).then(function(hit){
  var net=fetch(req,{cache:'reload'}).then(function(n){if(n&&n.ok){var cp=n.clone();caches.open(V).then(function(c){c.put(key,cp)})}return n}).catch(function(){return null});
  if(hit){e.waitUntil(net);return hit}
  return net.then(function(n){return n||Response.error()})})}
 function nf(key,url){return new Promise(function(res){var done=false;
  var fb=function(){return caches.match(key,{ignoreSearch:true})};
  var to=setTimeout(function(){fb().then(function(h){if(h&&!done){done=true;res(h)}})},9000);
  fetch(url,{cache:'no-store'}).then(function(n){if(n&&n.redirected&&n.url){if(!done){done=true;clearTimeout(to);res(Response.redirect(n.url,302))}return}if(n&&n.ok){var cp=n.clone();caches.open(V).then(function(c){c.put(key,cp)})}
   if(!done){done=true;clearTimeout(to);res(n)}}).catch(function(){clearTimeout(to);if(done)return;fb().then(function(h){done=true;res(h||Response.error())})})})}
 /* পেজ: আগে নেট (৯ সেকেন্ড), না পেলে ফোনে জমানো কপি। এতে নতুন ফাইল সাথে সাথে আসে, অফলাইনেও চলে */
 if(r.mode==='navigate'){e.respondWith(nf(NAV,r.url));return}
 if(u.origin===location.origin&&/\.(html|js|json)$/.test(u.pathname)){e.respondWith(swr(r,r.url));return}
 e.respondWith(caches.match(r,{ignoreSearch:true}).then(function(hit){
  /* Firebase মডিউল (gstatic) কখনো opaque কপি হিসেবে জমানো/দেওয়া হবে না: opaque কপি দিলে import() ব্যর্থ হয় */
  var fbjs=u.host==='www.gstatic.com';
  if(hit&&hit.type==='opaque'&&(fbjs||r.mode!=='no-cors'))hit=null;
  var net=fetch(r).then(function(n){if(n&&(n.ok||(n.type==='opaque'&&!fbjs))){var cp=n.clone();caches.open(V).then(function(c){c.put(r,cp)})}return n}).catch(function(){return hit||Response.error()});
  return hit||net}))});

self.addEventListener('notificationclick',function(e){e.notification.close();e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(function(l){for(var i=0;i<l.length;i++){if('focus' in l[i])return l[i].focus()}return clients.openWindow('./')}))});

self.addEventListener('notificationclick',function(e){e.notification.close();e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(function(l){for(var i=0;i<l.length;i++){if('focus' in l[i])return l[i].focus()}return self.clients.openWindow('./order.html')}))});
